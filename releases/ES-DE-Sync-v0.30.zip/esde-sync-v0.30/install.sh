#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_HOME="$HOME/.local/share/esde-sync"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"

mkdir -p "$APP_HOME/web" "$BIN_DIR" "$DESKTOP_DIR"

install -m 755 "$BASE_DIR/esde-sync-engine" "$APP_HOME/esde-sync-engine"
install -m 755 "$BASE_DIR/esde-sync-gui.py" "$APP_HOME/esde-sync-gui.py"
cp -r "$BASE_DIR/web/." "$APP_HOME/web/"

cat > "$BIN_DIR/esde-sync" <<EOF
#!/usr/bin/env bash
exec python3 "$APP_HOME/esde-sync-gui.py"
EOF
chmod +x "$BIN_DIR/esde-sync"

cat > "$DESKTOP_DIR/esde-sync.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=ES-DE Sync
Comment=Legion Go S 기준으로 Android ES-DE 라이브러리를 동기화합니다
Exec=$BIN_DIR/esde-sync
Icon=drive-removable-media
Terminal=false
Categories=Utility;Game;
StartupNotify=true
EOF
chmod +x "$DESKTOP_DIR/esde-sync.desktop"

echo "ES-DE Sync v0.30 설치 완료"
echo "앱 메뉴에서 ES-DE Sync를 실행하세요."

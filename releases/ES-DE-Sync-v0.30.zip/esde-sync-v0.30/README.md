# ES-DE Sync v0.30

## GitHub 기반 인앱 업데이트

v0.30부터 ES-DE Sync가 GitHub의 `version.json`을 확인합니다.

- 앱 시작/상태 갱신 시 최신 버전 확인
- 새 버전이 있으면 GUI에 업데이트 배너 표시
- `업데이트` 버튼 한 번으로 ZIP 다운로드
- `sha256` 값이 제공되면 SHA-256 검증
- 기존 설치 스크립트를 사용해 프로그램 파일 갱신
- `~/.config/esde-sync/profiles/`의 기기별 프로필은 보존
- 설치 후 ES-DE Sync 자동 재실행
- 업데이트 실패 시 `~/.local/state/esde-sync/update.log`에 기록

업데이트 메타데이터:
`https://raw.githubusercontent.com/dhlim89/esde-sync/main/version.json`

초기 v0.30 설치:
```bash
chmod +x install.sh && ./install.sh
```

v0.30 이후부터는 새 버전이 배포되면 앱 내부의 `업데이트` 버튼을 사용합니다.

#!/usr/bin/env bash
set -u
APP="$HOME/.local/share/esde-familyroom-updater"
STATE="$HOME/.local/state/esde-familyroom-updater"
URL="$STATE/current-url.txt"; PID="$STATE/server.pid"
BRAVE="$HOME/Applications/Brave-Origin/brave"
open_app(){ if [[ -x "$BRAVE" ]]; then "$BRAVE" --app="$1" --no-first-run --no-default-browser-check >/dev/null 2>&1 & else xdg-open "$1" >/dev/null 2>&1 & fi; }
if [[ -f "$PID" ]]; then P="$(cat "$PID" 2>/dev/null||true)"; if [[ -n "$P" ]] && kill -0 "$P" 2>/dev/null && [[ -s "$URL" ]]; then open_app "$(cat "$URL")"; exit 0; fi; fi
python3 "$APP/esde-familyroom-gui.py" >/dev/null 2>&1 &
for _ in {1..50}; do [[ -s "$URL" ]] && { open_app "$(cat "$URL")"; exit 0; }; sleep .1; done
exit 1

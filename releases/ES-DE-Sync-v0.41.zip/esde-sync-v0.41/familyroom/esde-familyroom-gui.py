#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs
from shutil import which
import html, os, re, shutil, subprocess, tempfile, time

SRC_ROMS=(Path.home()/"Emulation/roms")
SRC_GAMELISTS=(Path.home()/"ES-DE/gamelists")
SRC_MEDIA=(Path.home()/"Emulation/tools/downloaded_media")
DEST_ROOT=(Path.home()/"Dropbox/ES-DE Sync")
DEST_ROMS=DEST_ROOT/"roms"; DEST_GAMELISTS=DEST_ROOT/"gamelists"; DEST_MEDIA=DEST_ROOT/"downloaded_media"
CONFIG=Path.home()/".config/esde-familyroom-updater/systems.conf"
STATE=Path.home()/".local/state/esde-familyroom-updater"
LOG=STATE/"update.log"; URL_FILE=STATE/"current-url.txt"; PID_FILE=STATE/"server.pid"
STATE.mkdir(parents=True,exist_ok=True); CONFIG.parent.mkdir(parents=True,exist_ok=True)

ALT_MAP={
    "gb":{"Sameboy (Standalone)":"My OldBoy! (Standalone)"},
    "gbc":{"Sameboy (Standalone)":"My OldBoy! (Standalone)"},
}
ALT_RE=re.compile(r"(<altemulator>)(.*?)(</altemulator>)",re.S)

def log(s):
    with LOG.open("a",encoding="utf-8") as f: f.write(time.strftime("[%F %T] ")+s+"\n")

def systems():
    return sorted([p.name for p in SRC_ROMS.iterdir() if p.is_dir()],key=str.lower) if SRC_ROMS.is_dir() else []

def saved():
    if not CONFIG.exists(): return set()
    return {x.strip() for x in CONFIG.read_text(encoding="utf-8").splitlines() if x.strip() and not x.lstrip().startswith("#")}

def save(items):
    CONFIG.write_text("".join(f"{x}\n" for x in sorted(items,key=str.lower)),encoding="utf-8")

def supported_exts(sys):
    p=SRC_ROMS/sys/"systeminfo.txt"
    if not p.is_file(): return set()
    t=p.read_text(encoding="utf-8",errors="ignore")
    marker="Supported file extensions:"
    i=t.find(marker)
    if i<0: return set()
    block=t[i+len(marker):].split("\n\n",1)[0]
    return {x.lower() for x in re.findall(r"(?<!\w)\.[A-Za-z0-9][A-Za-z0-9+_-]*",block)}

def has_rom(sys):
    exts=supported_exts(sys)
    if not exts: return False
    for _,dirs,files in os.walk(SRC_ROMS/sys):
        dirs[:]=[d for d in dirs if not d.startswith(".")]
        for n in files:
            if not n.startswith(".") and Path(n).suffix.lower() in exts: return True
    return False

def safe(path):
    r=DEST_ROOT.resolve(); p=Path(path).resolve()
    return p!=r and str(p).startswith(str(r)+os.sep)

def remove(path,label):
    p=Path(path)
    if not p.exists() and not p.is_symlink(): return "skip"
    if not safe(p): log(f"REFUSE DELETE {label}: {p}"); return "fail"
    try:
        p.unlink() if p.is_symlink() or p.is_file() else shutil.rmtree(p)
        log(f"DELETE {label}: {p}"); return "deleted"
    except Exception as e:
        log(f"FAIL DELETE {label}: {e}"); return "fail"

def rsync_mirror(src,dst,label):
    src=Path(src); dst=Path(dst)
    if not src.is_dir(): return remove(dst,label+" source-missing")
    dst.mkdir(parents=True,exist_ok=True)
    p=subprocess.run(["rsync","-a","--delete","--delete-delay","--itemize-changes",str(src)+"/",str(dst)+"/"],text=True,capture_output=True)
    with LOG.open("a",encoding="utf-8") as f:
        if p.stdout:f.write(p.stdout)
        if p.stderr:f.write(p.stderr)
    log(("OK " if p.returncode==0 else "FAIL ")+label)
    return "ok" if p.returncode==0 else "fail"

def transform_file(path,sys):
    mp=ALT_MAP.get(sys,{})
    if not mp:return 0
    t=path.read_text(encoding="utf-8",errors="surrogateescape")
    c=0
    def repl(m):
        nonlocal c
        new=mp.get(m.group(2))
        if new is None:return m.group(0)
        c+=1; return m.group(1)+new+m.group(3)
    out=ALT_RE.sub(repl,t)
    if c:path.write_text(out,encoding="utf-8",errors="surrogateescape")
    return c

def gamelist_mirror(sys):
    src=SRC_GAMELISTS/sys; dst=DEST_GAMELISTS/sys
    if not src.is_dir(): return remove(dst,f"GAMELIST:{sys} source-missing"),0
    try:
        with tempfile.TemporaryDirectory(prefix=f"esde-{sys}-",dir=STATE) as td:
            tmp=Path(td)/sys
            shutil.copytree(src,tmp)
            count=sum(transform_file(p,sys) for p in tmp.rglob("*.xml"))
            if count: log(f"ALTEMU {sys}: {count} replacement(s)")
            return rsync_mirror(tmp,dst,f"GAMELIST:{sys}[Android]"),count
    except Exception as e:
        log(f"FAIL GAMELIST {sys}: {e}"); return "fail",0

def purge_unselected(sel):
    sel=set(sel); d=f=0
    for name,b in [("ROMS",DEST_ROMS),("GAMELISTS",DEST_GAMELISTS),("MEDIA",DEST_MEDIA)]:
        b.mkdir(parents=True,exist_ok=True)
        for child in list(b.iterdir()):
            if child.name in sel: continue
            r=remove(child,f"{name}:{child.name} unselected")
            d+=r=="deleted"; f+=r=="fail"
    return d,f

def page(msg="",err=False):
    ss=systems(); sv=saved(); first=not CONFIG.exists()
    rows=[]
    rc=0
    for s in ss:
        hr=has_rom(s); rc+=hr
        ck="checked" if (not first and s in sv) else ""
        rows.append(f'<label class="row" data-rom="{1 if hr else 0}"><input type="checkbox" name="system" value="{html.escape(s)}" {ck}><span>{html.escape(s)}</span><small>{"ROM 있음" if hr else "ROM 없음"}</small></label>')
    m=f'<div class="msg {"err" if err else ""}">{html.escape(msg)}</div>' if msg else ""
    return f"""<!doctype html><meta charset="utf-8"><title>Dropbox 공유 라이브러리 업데이트</title>
<style>body{{font-family:system-ui;margin:24px auto;max-width:760px;padding:0 20px}}button{{padding:9px 12px;margin:4px}}.list{{max-height:58vh;overflow:auto;border:1px solid #888;border-radius:10px}}.row{{display:grid;grid-template-columns:28px 1fr auto;padding:8px 12px;border-bottom:1px solid #8884}}small{{opacity:.6}}.note,.msg{{padding:10px;margin:12px 0;border-radius:8px;background:#8882}}.err{{background:#c334}}</style>
<h1>Dropbox 공유 라이브러리 업데이트</h1>
<p>Android용 ES-DE 배포본 · {html.escape(str(DEST_ROOT))}</p>
<p>전체 {len(ss)}개 · 실제 ROM 감지 {rc}개</p>{m}
<form method="post" action="/update">
<button type="button" onclick="allx(true)">전체 선택</button><button type="button" onclick="allx(false)">전체 해제</button><button type="button" onclick="romonly()">ROM 있는 시스템만</button>
<span id="cnt"></span><div class="list">{''.join(rows)}</div>
<div class="note">gamelist는 Linux 원본을 수정하지 않고 Android용 사본으로 변환합니다. GB/GBC의 Sameboy (Standalone) → My OldBoy! (Standalone)만 정확히 변환하며 RetroArch SameBoy는 유지합니다.</div>
<div class="note">선택 해제 시스템과 리전고S에서 삭제된 파일은 Dropbox 배포본에서도 삭제됩니다.</div>
<button type="submit">선택 저장 및 Android 배포본 업데이트</button></form>
<script>
const bs=()=>[...document.querySelectorAll('input[name=system]')];
function upd(){{document.querySelector('#cnt').textContent=bs().filter(x=>x.checked).length+' / '+bs().length+' 선택'}}
function allx(v){{bs().forEach(x=>x.checked=v);upd()}}
function romonly(){{bs().forEach(x=>x.checked=x.closest('.row').dataset.rom==='1');upd()}}
bs().forEach(x=>x.onchange=upd);upd();
</script>"""

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def sendh(self,t,status=200):
        b=t.encode(); self.send_response(status); self.send_header("Content-Type","text/html; charset=utf-8"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        self.sendh(page()) if self.path=="/" or self.path.startswith("/?") else self.send_error(404)
    def do_POST(self):
        if self.path!="/update": self.send_error(404); return
        n=int(self.headers.get("Content-Length","0")); f=parse_qs(self.rfile.read(n).decode())
        valid=set(systems()); sel=[x for x in f.get("system",[]) if x in valid]; save(sel)
        if not which("rsync"): self.sendh(page("rsync를 찾을 수 없습니다.",True),500); return
        DEST_ROMS.mkdir(parents=True,exist_ok=True); DEST_GAMELISTS.mkdir(parents=True,exist_ok=True); DEST_MEDIA.mkdir(parents=True,exist_ok=True)
        ok=dele=skip=fail=conv=0
        d,x=purge_unselected(sel); dele+=d; fail+=x
        for s in sel:
            for src,dst,label in [(SRC_ROMS/s,DEST_ROMS/s,f"ROM:{s}")]:
                r=rsync_mirror(src,dst,label); ok+=r=="ok"; dele+=r=="deleted"; skip+=r=="skip"; fail+=r=="fail"
            r,c=gamelist_mirror(s); conv+=c; ok+=r=="ok"; dele+=r=="deleted"; skip+=r=="skip"; fail+=r=="fail"
            r=rsync_mirror(SRC_MEDIA/s,DEST_MEDIA/s,f"MEDIA:{s}"); ok+=r=="ok"; dele+=r=="deleted"; skip+=r=="skip"; fail+=r=="fail"
        log(f"RESULT ok={ok} del={dele} skip={skip} fail={fail} alt={conv}")
        self.sendh(page(f"업데이트 완료: 선택 {len(sel)}개 · 삭제 {dele} · 대체 에뮬레이터 변환 {conv} · 실패 {fail}",fail>0))

if __name__=="__main__":
    if DEST_ROOT!=(Path.home()/"Dropbox/ES-DE Sync"): raise SystemExit(2)
    srv=ThreadingHTTPServer(("127.0.0.1",0),H)
    url=f"http://127.0.0.1:{srv.server_address[1]}/"
    URL_FILE.write_text(url); PID_FILE.write_text(str(os.getpid()))
    try:srv.serve_forever()
    finally:
        for p in (URL_FILE,PID_FILE):
            try:p.unlink()
            except:pass

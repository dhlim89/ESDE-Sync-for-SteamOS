#!/usr/bin/env bash
set -u

TARGET="${1:-}"
HOME_DIR="$HOME"

parse_exec() {
    local file="$1"
    [[ -f "$file" ]] || return 1
    grep -m1 '^Exec=' "$file" | sed 's/^Exec=//' | \
        sed -E 's/%[UuFfick]//g'
}

launch_cmd() {
    local cmd="$1"
    [[ -n "$cmd" ]] || exit 1
    /bin/bash -lc "$cmd" >/dev/null 2>&1 &
}

case "$TARGET" in
    android)
        CMD=""
        if [[ -x "$HOME_DIR/.local/bin/esde-sync" ]]; then
            CMD="\"$HOME_DIR/.local/bin/esde-sync\""
        fi
        if [[ -z "$CMD" ]]; then
            for P in \
                "$HOME_DIR/.local/share/esde-sync/esde-sync-launch.sh" \
                "$HOME_DIR/.local/share/esde-sync/esde-sync-gui.py" \
                "$HOME_DIR/.local/share/esde-sync/esde-sync.sh"
            do
                if [[ -e "$P" ]]; then
                    [[ "$P" == *.py ]] && CMD="python3 \"$P\"" || CMD="\"$P\""
                    break
                fi
            done
        fi
        launch_cmd "$CMD"
        ;;
    family)
        P="$HOME_DIR/.local/share/esde-familyroom-updater/esde-familyroom-launch.sh"
        [[ -x "$P" ]] || exit 1
        launch_cmd "\"$P\""
        ;;
    *)
        exit 2
        ;;
esac

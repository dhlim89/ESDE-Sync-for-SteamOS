#!/usr/bin/env bash
set -u

APP_DIR="$HOME/.local/share/esde-sync-hub"
STATE_DIR="$HOME/.local/state/esde-sync-hub"
URL_FILE="$STATE_DIR/current-url.txt"
PID_FILE="$STATE_DIR/server.pid"
BRAVE="$HOME/Applications/Brave-Origin/brave"

open_app() {
    local url="$1"

    if [[ -x "$BRAVE" ]]; then
        "$BRAVE" \
            --app="$url" \
            --no-first-run \
            --no-default-browser-check \
            >/dev/null 2>&1 &
        return 0
    fi

    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$url" >/dev/null 2>&1 &
        return 0
    fi

    return 1
}

if [[ -f "$PID_FILE" ]]; then
    PID="$(cat "$PID_FILE" 2>/dev/null || true)"
    if [[ -n "$PID" ]] && kill -0 "$PID" 2>/dev/null; then
        if [[ -s "$URL_FILE" ]]; then
            open_app "$(cat "$URL_FILE")"
            exit 0
        fi
    else
        rm -f "$PID_FILE" "$URL_FILE"
    fi
fi

python3 "$APP_DIR/esde-sync-hub.py" >/dev/null 2>&1 &

for _ in {1..50}; do
    if [[ -s "$URL_FILE" ]]; then
        open_app "$(cat "$URL_FILE")"
        exit 0
    fi
    sleep 0.1
done

if command -v kdialog >/dev/null 2>&1; then
    kdialog --title "ES-DE Sync" --error "통합 앱 화면을 열지 못했습니다."
fi
exit 1

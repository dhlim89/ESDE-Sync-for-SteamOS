#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs
import html, os, subprocess, time

APP_NAME = "ES-DE Sync"
HOME = Path.home()

STATE_DIR = HOME / ".local/state/esde-sync-hub"
URL_FILE = STATE_DIR / "current-url.txt"
PID_FILE = STATE_DIR / "server.pid"
LOG_FILE = STATE_DIR / "hub.log"

ANDROID_DESKTOP = HOME / ".local/share/applications/esde-sync.desktop"
ANDROID_DIR = HOME / ".local/share/esde-sync"

FAMILY_DESKTOP = HOME / ".local/share/applications/esde-familyroom-update.desktop"
FAMILY_DIR = HOME / ".local/share/esde-familyroom-updater"



def log(text):
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(time.strftime("[%Y-%m-%d %H:%M:%S] ") + text + "\n")

def parse_desktop_exec(path):
    if not path.is_file():
        return None
    try:
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("Exec="):
                return line[5:].strip()
    except OSError:
        pass
    return None

def find_android_command():
    binary = HOME / ".local/bin/esde-sync"
    if binary.is_file():
        return f'"{binary}"'

    # Legacy installation fallback
    cmd = parse_desktop_exec(ANDROID_DESKTOP)
    if cmd:
        return cmd

    # 2) 알려진 설치 구조를 자동 탐색
    candidates = [
        ANDROID_DIR / "esde-sync-launch.sh",
        ANDROID_DIR / "esde-sync-gui.py",
        ANDROID_DIR / "esde-sync.sh",
    ]
    for p in candidates:
        if p.exists():
            if p.suffix == ".py":
                return f'python3 "{p}"'
            return f'"{p}"'
    return None

def find_family_command():
    launcher = FAMILY_DIR / "esde-familyroom-launch.sh"
    if launcher.is_file() and os.access(launcher, os.X_OK):
        return f'"{launcher}"'
    return None

def launch_shell(command):
    if not command:
        return False, "실행 파일을 찾지 못했습니다."

    try:
        # Desktop Exec의 %U/%u/%F 등의 field code 제거
        cleaned = command
        for code in ["%U", "%u", "%F", "%f", "%i", "%c", "%k"]:
            cleaned = cleaned.replace(code, "")
        subprocess.Popen(
            ["/bin/bash", "-lc", cleaned],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        log("LAUNCH " + cleaned)
        return True, ""
    except Exception as e:
        log(f"LAUNCH FAIL {command}: {e}")
        return False, str(e)

def status_data():
    a = find_android_command()
    f = find_family_command()
    return {
        "android_ok": bool(a),
        "family_ok": bool(f),
        "android_cmd": a or "",
        "family_cmd": f or "",
    }

def render_page(message="", error=False):
    st = status_data()
    msg = ""
    if message:
        msg = f'<div class="message {"error" if error else "ok"}">{html.escape(message)}</div>'

    android_status = "사용 가능" if st["android_ok"] else "기존 프로그램을 찾지 못함"
    family_status = "사용 가능" if st["family_ok"] else "기존 프로그램을 찾지 못함"

    android_disabled = "" if st["android_ok"] else "disabled"
    family_disabled = "" if st["family_ok"] else "disabled"

    template = """<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>ES-DE Sync</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root { color-scheme: light dark; font-family: system-ui,"Pretendard","Noto Sans KR",sans-serif; }
body { margin:0; background:Canvas; color:CanvasText; }
.wrap { max-width:760px; margin:34px auto; padding:0 24px 36px; }
h1 { font-size:28px; margin:0 0 6px; }
.subtitle { opacity:.68; margin-bottom:24px; }
.grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.card { border:1px solid color-mix(in srgb, GrayText 60%, transparent); border-radius:14px; padding:20px; min-height:210px; display:flex; flex-direction:column; }
.icon { font-size:38px; line-height:1; margin-bottom:16px; }
.card h2 { font-size:20px; margin:0 0 8px; }
.desc { opacity:.75; line-height:1.55; flex:1; }
.status { font-size:13px; margin:12px 0; opacity:.72; }
button { width:100%; padding:11px 14px; border-radius:9px; border:1px solid GrayText; font:inherit; font-weight:700; cursor:pointer; }
button:disabled { opacity:.45; cursor:not-allowed; }
.message { margin:0 0 18px; padding:12px 14px; border-radius:9px; }
.message.ok { background:color-mix(in srgb, #2e9b4b 18%, transparent); }
.message.error { background:color-mix(in srgb, #c43d3d 20%, transparent); }
.footer { margin-top:20px; font-size:13px; opacity:.58; line-height:1.55; }
@media (max-width:680px) { .grid { grid-template-columns:1fr; } }
</style>
</head>
<body>
<div class="wrap">
  <h1>ES-DE Sync</h1>
  <div class="subtitle">리전고S의 ES-DE 라이브러리 동기화를 한 곳에서 관리합니다.</div>
  __MESSAGE__

  <div class="grid">
    <div class="card">
      <div class="icon">🎮</div>
      <h2>Android 기기 동기화</h2>
      <div class="desc">
        USB ADB로 연결한 Retroid Pocket Classic, AYANEO Pocket Air Mini 등
        Android 기기에 ROM · gamelist · downloaded_media를 동기화합니다.
      </div>
      <div class="status">__ANDROID_STATUS__</div>
      <form method="post" action="/launch">
        <input type="hidden" name="target" value="android">
        <button type="submit" __ANDROID_DISABLED__>Android 동기화 열기</button>
      </form>
    </div>

    <div class="card">
      <div class="icon">☁️</div>
      <h2>Dropbox 공유 라이브러리 업데이트</h2>
      <div class="desc">
        선택한 시스템의 ROM · gamelist · downloaded_media를
        내 Dropbox의 ES-DE Sync 공유 라이브러리와 정확히 미러링합니다.
      </div>
      <div class="status">__FAMILY_STATUS__</div>
      <form method="post" action="/launch">
        <input type="hidden" name="target" value="family">
        <button type="submit" __FAMILY_DISABLED__>공유 라이브러리 업데이트 열기</button>
      </form>
    </div>
  </div>

  <div class="footer">
    통합 허브는 기존 두 프로그램의 설정과 동기화 엔진을 그대로 사용합니다.
    따라서 Android 기기 프로필과 공유 라이브러리 시스템 선택값은 유지됩니다.
  </div>
</div>
</body>
</html>"""

    return (template
            .replace("__MESSAGE__", msg)
            .replace("__ANDROID_STATUS__", android_status)
            .replace("__FAMILY_STATUS__", family_status)
            .replace("__ANDROID_DISABLED__", android_disabled)
            .replace("__FAMILY_DISABLED__", family_disabled))

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def send_html(self, text, status=200):
        data = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/" or self.path.startswith("/?"):
            self.send_html(render_page())
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path != "/launch":
            self.send_error(404)
            return

        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8")
        form = parse_qs(body)
        target = form.get("target", [""])[0]

        if target == "android":
            cmd = find_android_command()
            ok, detail = launch_shell(cmd)
            if ok:
                self.send_html(render_page("Android 동기화 프로그램을 열었습니다."))
            else:
                self.send_html(render_page("Android 동기화 프로그램을 실행하지 못했습니다: " + detail, True))
        elif target == "family":
            cmd = find_family_command()
            ok, detail = launch_shell(cmd)
            if ok:
                self.send_html(render_page("공유 라이브러리 업데이트 프로그램을 열었습니다."))
            else:
                self.send_html(render_page("공유 라이브러리 업데이트 프로그램을 실행하지 못했습니다: " + detail, True))
        else:
            self.send_html(render_page("알 수 없는 작업입니다.", True), 400)

def cleanup():
    for p in (URL_FILE, PID_FILE):
        try:
            p.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            pass

if __name__ == "__main__":
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/"

    URL_FILE.write_text(url, encoding="utf-8")
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    log("SERVER START " + url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        cleanup()
        log("SERVER STOP")

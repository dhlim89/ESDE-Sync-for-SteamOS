# ES-DE Sync v0.41
`bash install.sh`로 Android Sync, 통합 허브, Dropbox 공유 라이브러리 updater를 설치한다.
KDE 메뉴에는 ES-DE Sync 통합 허브만 등록한다.
필수 시스템 도구: Python 3(표준 라이브러리), Bash, ADB(Android용), rsync(Dropbox용), Brave 또는 xdg-open과 기본 브라우저.
별도 familyroom 앱 설치는 필요 없다. Dropbox 계정/클라이언트와 로컬 ROM은 사용자가 준비한다.
Dropbox 기본 경로는 현재 HOME의 `Dropbox/ES-DE Sync`, 소스는 `Emulation/roms`, `ES-DE/gamelists`, `Emulation/tools/downloaded_media`이다.
기존 설정/profile/state/Dropbox 폴더와 familyroom 설치 폴더의 배포 코드 이외 파일은 보존한다.
familyroom 배포 코드는 esde-familyroom-launch.sh 및 esde-familyroom-gui.py 두 파일만 교체한다.
